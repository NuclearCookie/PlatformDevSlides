#pragma once


enum class Mode
{
    Read,
    Write,
    ReadWrite
};
